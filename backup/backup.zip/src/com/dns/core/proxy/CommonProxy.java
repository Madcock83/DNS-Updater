package com.dns.core.proxy;

public class CommonProxy {

    public void registerTickHandler() {

    }

}
